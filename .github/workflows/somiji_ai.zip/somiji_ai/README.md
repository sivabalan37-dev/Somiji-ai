# SOMIJI AI

A personal AI assistant by SOMIJI: a web interface plus a small Python backend, with a login so you can run it online. API keys stay on the server and never reach the browser.

## Run it on your computer

Requires Python 3.9+. There are no packages to install.

```
cd somiji_ai
cp .env.example .env     # add a key, or leave it empty for demo mode
python3 server.py
```

Open http://127.0.0.1:8000. On your own machine no password is needed.

## Put it online

The server refuses to start on a public address without a login, so a forgotten password can't leave your API credit open to the internet.

**Render (simplest):**
1. Put this folder in a GitHub repository (`.env` is git-ignored).
2. In Render choose New, then Blueprint, and pick the repository. It reads `render.yaml`.
3. Fill in `SOMIJI_PASSWORD` (10+ characters) and the API key you use. If Render insists on a value for a key you don't use, delete that entry from `render.yaml` first.
4. Open the `https://...onrender.com` address and sign in.

`render.yaml` selects Render's free plan, which can sleep when idle and wake slowly; check Render's current terms or change `plan`.

**Any Docker host or VPS** (Railway, Fly.io, Cloud Run, your own server):
```
docker build -t somiji-ai .
docker run -p 8000:8000 -e SOMIJI_PASSWORD="your long passphrase" -e OPENAI_API_KEY=... somiji-ai
```
Put HTTPS in front (most hosts do this for you). Without Docker, any host that runs Python 3.9+ works with the start command `python server.py`.

**On your phone:** open the online address in Chrome. HTTPS is what lets voice input work there. Use the browser menu's Add to Home screen for a shortcut.

## Configure (.env or host environment)

| Setting | Purpose |
|---|---|
| `SOMIJI_PASSWORD` | Login password. Required for any address other than 127.0.0.1 |
| `ANTHROPIC_API_KEY`, `OPENAI_API_KEY` | Enable those providers |
| `ANTHROPIC_MODELS`, `OPENAI_MODELS` | Comma-separated model names your account can use (the defaults are examples, check them) |
| `OLLAMA_MODELS`, `OLLAMA_BASE_URL` | Local models through Ollama (install it and `ollama pull` a model first) |
| `HOST`, `PORT` | Default `127.0.0.1:8000`; if the host sets `PORT`, `HOST` defaults to `0.0.0.0` |
| `TRUST_PROXY=1` | Set behind a hosting proxy so rate limits use the real client address (the Dockerfile and `render.yaml` set it) |
| `CHAT_PER_MIN` | Messages per minute per client, default 30 |
| `ALLOW_NO_AUTH=1` | Reachable with no password. Trusted private networks only |

With no keys, only a demo model appears. It echoes your text and is not an AI.

## Features

Streaming chat, history with new and delete chat, model picker, image and text-file attachments (5 MB limit; text is cut at 100 KB), voice input and read-aloud (your browser's speech features), dark and light themes, your name and custom instructions, responsive layout, login and sign out.

## Security

- Keys live only in the server's environment or `.env`. The browser only talks to `/api/*`.
- Login is one shared password. Sessions are signed cookies (HttpOnly, SameSite=Strict, Secure over HTTPS) lasting 30 days. Five wrong passwords lock a client out for five minutes. Cross-site POSTs are rejected.
- Sign out clears the cookie in that browser only. To end every session, change `SOMIJI_PASSWORD`.
- Chats and settings are stored in each browser, not on the server. They don't sync between devices, and on a shared computer they stay in that browser until cleared. Image data is not kept in saved history.

## Status

Tested in a sandbox with no internet (`python3 -m unittest discover -s tests -v`, 12 tests):
- Login required for `/api/models` and `/api/chat`; wrong password rejected; tampered and expired cookies rejected; cookie flags; Secure cookie and HSTS behind an HTTPS proxy; cross-site POST blocked; logout; login and chat rate limits.
- Refuses to start on a public address without a password, including when a host sets only `PORT`.
- Demo mode and the streaming relay in OpenAI/Ollama format against a local mock; unknown model rejected; path traversal blocked; password absent from served pages.
- UI in headless Chromium under the page's own security policy: login screen, wrong and right password, streamed demo reply, session and history survive reload, sign out, mobile width without horizontal scroll, no script errors.

Not tested: live calls to Anthropic, OpenAI or Ollama; the Anthropic relay and image payloads in this round (that code is unchanged from the earlier build); microphone input and spoken playback; Safari and Firefox; the Docker build; a real deployment.

Not included: agents and skills, document indexing and memory, scheduled briefings, connectors, desktop installers, server-side chat storage, installable-app (PWA) support.

## Layout

```
server.py              backend: login, static files, /api/models, /api/chat relay
static/index.html      the interface
static/logo.svg        logo and icon
tests/test_server.py   backend tests
Dockerfile, render.yaml, .dockerignore, .gitignore, .env.example
```

## Credits

Inspired by the OpenJarvis project (Apache-2.0). SOMIJI AI is separate code and contains none of its code or branding.
