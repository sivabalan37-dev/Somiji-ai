"""Backend tests, standard library only:  python3 -m unittest discover -s tests -v
Starts the real server.py on free local ports. The model relay is tested against a local
mock that speaks the OpenAI streaming format (standing in for Ollama); no internet is used."""
import hashlib, hmac, http.server, json, os, socket, subprocess, sys, threading, time, unittest
import urllib.error, urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PW = "correct horse battery"


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


class Mock(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_POST(self):
        self.rfile.read(int(self.headers["Content-Length"]))
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.end_headers()
        for w in ("mock", " reply"):
            self.wfile.write(b"data: " + json.dumps({"choices": [{"delta": {"content": w}}]}).encode() + b"\n\n")
        self.wfile.write(b"data: [DONE]\n\n")


def call(base, path, data=None, headers=None):
    h = dict(headers or {})
    body = None
    if data is not None:
        body = json.dumps(data).encode()
        h["Content-Type"] = "application/json"
    try:
        r = urllib.request.urlopen(urllib.request.Request(base + path, body, h), timeout=15)
    except urllib.error.HTTPError as e:
        r = e
    out = (r.status if hasattr(r, "status") else r.code), r.headers, r.read().decode("utf-8", "replace")
    r.close()
    return out


def sse(body):
    """Return (joined text, saw_done) from a server-sent-events body."""
    evs = [json.loads(l[5:]) for l in body.splitlines() if l.startswith("data:")]
    return "".join(e.get("t", "") for e in evs), any(e.get("done") for e in evs)


class Server:
    def __init__(self, **env):
        self.port = free_port()
        e = {k: v for k, v in os.environ.items() if not k.startswith(("SOMIJI", "ANTHROPIC", "OPENAI", "OLLAMA"))}
        e.update(HOST="127.0.0.1", PORT=str(self.port), **env)
        self.proc = subprocess.Popen([sys.executable, str(ROOT / "server.py")], env=e, cwd=ROOT,
                                     stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        self.base = f"http://127.0.0.1:{self.port}"
        for _ in range(50):
            try:
                urllib.request.urlopen(self.base + "/healthz", timeout=1).close()
                return
            except Exception:
                time.sleep(0.1)
        raise RuntimeError("server did not start")

    def login(self):
        s, h, _ = call(self.base, "/api/login", {"password": PW})
        assert s == 200
        return {"Cookie": h["Set-Cookie"].split(";")[0]}

    def stop(self):
        self.proc.terminate()
        self.proc.wait(5)
        self.proc.stdout.close()


class Auth(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.mock = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Mock)
        threading.Thread(target=cls.mock.serve_forever, daemon=True).start()
        cls.s = Server(SOMIJI_PASSWORD=PW, OLLAMA_MODELS="mock", CHAT_PER_MIN="1000",
                       OLLAMA_BASE_URL=f"http://127.0.0.1:{cls.mock.server_address[1]}/v1")

    @classmethod
    def tearDownClass(cls):
        cls.s.stop()
        cls.mock.shutdown()
        cls.mock.server_close()

    def test_01_public_pages_and_no_secrets(self):
        self.assertEqual(call(self.s.base, "/healthz")[0], 200)
        st, _, html = call(self.s.base, "/")
        self.assertEqual(st, 200)
        self.assertIn("SOMIJI AI", html)
        self.assertNotIn(PW, html)
        self.assertEqual(call(self.s.base, "/%2e%2e/server.py")[0], 404)
        self.assertEqual(call(self.s.base, "/../server.py")[0], 404)

    def test_02_api_needs_login(self):
        self.assertEqual(call(self.s.base, "/api/models")[0], 401)
        self.assertEqual(call(self.s.base, "/api/chat", {"model": "demo:demo-echo", "messages": []})[0], 401)
        self.assertEqual(json.loads(call(self.s.base, "/api/session")[2]), {"authRequired": True, "authed": False})

    def test_03_login_cookie_and_bad_tokens(self):
        st, h, _ = call(self.s.base, "/api/login", {"password": "nope"})
        self.assertEqual(st, 401)
        self.assertNotIn("Set-Cookie", h)
        ok = self.s.login()
        st, h, _ = call(self.s.base, "/api/login", {"password": PW})
        flags = h["Set-Cookie"]
        self.assertTrue("HttpOnly" in flags and "SameSite=Strict" in flags and "Secure" not in flags)
        st, _, body = call(self.s.base, "/api/models", headers=ok)
        ids = [m["id"] for m in json.loads(body)["models"]]
        self.assertEqual(st, 200)
        self.assertIn("demo:demo-echo", ids)
        self.assertIn("ollama:mock", ids)
        self.assertEqual(json.loads(call(self.s.base, "/api/session", headers=ok)[2])["authed"], True)
        bad = ok["Cookie"][:-3] + "abc"
        self.assertEqual(call(self.s.base, "/api/models", headers={"Cookie": bad})[0], 401)
        exp = int(time.time()) - 10  # correctly signed but expired
        key = hashlib.sha256(b"somiji-session|" + PW.encode()).digest()
        mac = hmac.new(key, str(exp).encode(), hashlib.sha256).hexdigest()
        self.assertEqual(call(self.s.base, "/api/models", headers={"Cookie": f"somiji_session={exp}.{mac}"})[0], 401)

    def test_04_chat_relay_and_validation(self):
        ok = self.s.login()
        msg = [{"role": "user", "text": "hi", "images": []}]
        st, _, body = call(self.s.base, "/api/chat", {"model": "demo:demo-echo", "messages": msg}, ok)
        text, done = sse(body)
        self.assertTrue(st == 200 and done and text.endswith("You said: hi "), text)
        st, _, body = call(self.s.base, "/api/chat", {"model": "ollama:mock", "messages": msg}, ok)
        self.assertEqual((st, sse(body)), (200, ("mock reply", True)))
        self.assertEqual(call(self.s.base, "/api/chat", {"model": "openai:gpt-x", "messages": msg}, ok)[0], 400)

    def test_05_cross_site_post_blocked(self):
        st, _, _ = call(self.s.base, "/api/login", {"password": PW}, {"Origin": "http://evil.example"})
        self.assertEqual(st, 403)
        st, _, _ = call(self.s.base, "/api/login", {"password": PW}, {"Origin": self.s.base})
        self.assertEqual(st, 200)

    def test_06_logout_clears_cookie(self):
        st, h, _ = call(self.s.base, "/api/logout", {})
        self.assertTrue(st == 200 and "Max-Age=0" in h["Set-Cookie"])

    def test_07_https_behind_proxy(self):
        st, h, _ = call(self.s.base, "/api/login", {"password": PW}, {"X-Forwarded-Proto": "https"})
        self.assertTrue(st == 200 and "Secure" in h["Set-Cookie"] and "Strict-Transport-Security" in h)

    def test_99_login_rate_limit(self):  # last: it locks this client out for five minutes
        codes = [call(self.s.base, "/api/login", {"password": "x"})[0] for _ in range(6)]  # one failure already used
        self.assertEqual(codes[0], 401)
        self.assertEqual(codes[-2:], [429, 429])
        self.assertEqual(call(self.s.base, "/api/login", {"password": PW})[0], 429)  # even the right password waits


class Modes(unittest.TestCase):
    def test_chat_rate_limit(self):
        s = Server(SOMIJI_PASSWORD=PW, CHAT_PER_MIN="2")
        try:
            ok, msg = s.login(), [{"role": "user", "text": "hi"}]
            codes = [call(s.base, "/api/chat", {"model": "demo:demo-echo", "messages": msg}, ok)[0] for _ in range(3)]
            self.assertEqual(codes, [200, 200, 429])
        finally:
            s.stop()

    def test_local_mode_without_password(self):
        s = Server()
        try:
            self.assertEqual(json.loads(call(s.base, "/api/session")[2]), {"authRequired": False, "authed": True})
            self.assertEqual(call(s.base, "/api/models")[0], 200)
        finally:
            s.stop()

    def test_refuses_public_bind_without_password(self):
        e = {k: v for k, v in os.environ.items() if not k.startswith(("SOMIJI", "ALLOW"))}
        e.update(HOST="0.0.0.0", PORT=str(free_port()))
        r = subprocess.run([sys.executable, str(ROOT / "server.py")], env=e, cwd=ROOT, capture_output=True, text=True, timeout=10)
        self.assertNotEqual(r.returncode, 0)
        self.assertIn("Refusing", r.stderr)

    def test_host_defaults_to_public_when_platform_sets_port(self):
        e = {k: v for k, v in os.environ.items() if not k.startswith(("SOMIJI", "ALLOW", "HOST"))}
        e["PORT"] = str(free_port())  # no HOST, no password: must refuse, proving it chose 0.0.0.0
        r = subprocess.run([sys.executable, str(ROOT / "server.py")], env=e, cwd=ROOT, capture_output=True, text=True, timeout=10)
        self.assertNotEqual(r.returncode, 0)


if __name__ == "__main__":
    unittest.main()
